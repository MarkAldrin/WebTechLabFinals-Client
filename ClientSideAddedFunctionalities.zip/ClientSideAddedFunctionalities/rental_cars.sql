-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rental
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_number` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `transmission` varchar(255) DEFAULT NULL,
  `capacity` int(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `date1` date DEFAULT NULL,
  `date2` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'AYX 2552','SUV','2008','Honda','Manual',5,2500,'','AVIS','Pending','0000-00-00',NULL,'2018-06-09','2018-06-16'),(2,'AYR 3022','VAN','2014','Mitsubishi','Manual',9,3000,NULL,'RBC','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(3,'AYT 3488','Sedan','2018','Toyota','Automatic',6,2750,NULL,'AVIS','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(4,'AHN 5662','Pickup','2004','Isuzu','Manual',6,2750,NULL,'RBC','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(5,'AYN 7890','Truck','2003','Mitsubishi','Manual',2,2000,NULL,'BCR','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(6,'AZX 9912','VAN','2012','Honda','Automatic',5,2500,NULL,'BCR','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(7,'AZX 9912','VAN','2012','Honda','Automatic',5,2500,NULL,'RENTME','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(8,'AZX 9912','VAN','2012','Honda','Automatic',5,2500,NULL,'RENTME','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(9,'AZX 9912','Sedan','2014','Toyota','Automatic',9,3000,NULL,'RBC','Available','0000-00-00',NULL,'0000-00-00','0000-00-00'),(10,'AZX 9912','Truck','2008','Isuzu','Manual',6,2000,NULL,'Sample','Available','0000-00-00',NULL,'0000-00-00','0000-00-00');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-02  2:28:39
