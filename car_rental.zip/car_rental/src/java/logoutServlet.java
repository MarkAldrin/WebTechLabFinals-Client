
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author KUPS
 */
public class logoutServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession session = request.getSession();
            String username = (String) session.getAttribute("username");
            if (!session.getAttribute("username").equals(null)) {
                try {
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/rental", "root", "");
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM user WHERE user_name='" + username + "' AND availability='online'");
                    if (rs.first()) {
                        Class.forName("com.mysql.jdbc.Driver");
                        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/rental", "root", "");
                        String query = "UPDATE user set availability = ? where user_name = ?";
                        PreparedStatement pst = (PreparedStatement) con.prepareStatement(query);
                        pst.setString(1, "offline");
                        pst.setString(2, username);
                        pst.executeUpdate();
                    }
                } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
                    
                }
                   session.invalidate();
                    response.sendRedirect("login.jsp");
            }

        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();
        response.sendRedirect("login.jsp");
    }
}
