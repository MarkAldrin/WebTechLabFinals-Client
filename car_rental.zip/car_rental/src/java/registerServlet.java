import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

public class registerServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

                PrintWriter pw = response.getWriter();  

                String user_name = request.getParameter("username");
                String password = request.getParameter("password");
                String firstname = request.getParameter("firstname");
                String lastname = request.getParameter("lastname");
                String email = request.getParameter("email");
                String address = request.getParameter("address");
                String contact = request.getParameter("contact");


                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection connection;
                    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rental", "root", "");
                        
                    PreparedStatement ps;
                    String query = "INSERT INTO user(user_name, password, firstname, lastname, email, address, contact_num) values(?,?,?,?,?,?,?)";
                      ps = connection.prepareStatement(query);


                    ps.setString(1, user_name);
                    ps.setString(2, password);
                    ps.setString(3, firstname);
                    ps.setString(4, lastname);
                    ps.setString(5, email);
                    ps.setString(6, address);
                    ps.setString(7, contact);
                    


                    int rs = ps.executeUpdate();

                    if(rs > 0){
                        response.sendRedirect("login.jsp");
                    } else {
                        response.sendRedirect("Failed!");
                    }

            }   catch (ClassNotFoundException ex) {
                            System.out.println(ex);
            }   catch (SQLException ex) {
                    Logger.getLogger(registerServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    
}
