import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Kupal
 */
public class rentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String status = request.getParameter("changeStatus");
        String idno = request.getParameter("id");
        String userID = request.getParameter("userid") ;
        String days = request.getParameter("days");
        String username = request.getParameter("username");
        String car_status = request.getParameter("car_status");
        String date1 = request.getParameter("date1");
        String date2 = request.getParameter("date2");
        
        try(PrintWriter pw = response.getWriter()){

        if(status.equalsIgnoreCase("Rent")){
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/rental", "root" , "");
                  String query = "UPDATE cars set car_status=?, date1=? , date2=? where id=?";

                   PreparedStatement pst = (PreparedStatement) conn.prepareStatement(query);

                   pst.setString(1, "Pending");
                   pst.setString(2, date1);
                   pst.setString(3, date2);
                   pst.setString(4, idno);

                   int rs = pst.executeUpdate();
                        
                        if (rs>0) {
                            response.sendRedirect("cars.jsp");    
                        }
                        else {
                                System.out.println("Error!");
                                
                         }
                    
            } catch (IOException | ClassNotFoundException | SQLException ex) {
                Logger.getLogger(rentServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
              
        } else if (status.equalsIgnoreCase("Cancel")) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/rental", "root" , "");
                  String query = "UPDATE cars set car_status=?, date1 = 0000-00-00, date2=0000-00-00 where id=?";

                   PreparedStatement pst = (PreparedStatement) conn.prepareStatement(query);

                   pst.setString(1, "Available");
                   pst.setString(2, idno);

                   int rs = pst.executeUpdate();
                        
                        if (rs>0) {
                            response.sendRedirect("cars.jsp");    
                        }
                        else {
                                System.out.println("Error!");
                                
                         }
                    
            } catch (IOException | ClassNotFoundException | SQLException ex) {
                Logger.getLogger(rentServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        

     }   
    }
    }
}
